﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Pacman
{
     class Pacman : ObjetAnime
    {
        private char direction;
        private String text = "pacmanGauche0";
        public Pacman(Texture2D texture) : base(texture, new Vector2(13.5f, 23), new Vector2(20f, 20f))
        {
            this.direction = 'G';
        }


        public char Direction
        {
            get { return direction; }
            set { direction = value; }
        }

        public String Text
        {
            get { return text; }
            set { text = value; }
        }

        public void deplacer(int num_texture)
        {
            switch(this.Direction)
            {
                case 'G':
                    Position = new Vector2(Position.X - 0.2f, Position.Y);
                    switch(num_texture)
                    {
                        case 0:
                            text = "pacmanGauche0";
                            break;
                        case 1:
                            text = "pacmanGauche1";
                            break;
                        case 2:
                            text = "pacman_2f";
                            break;
                    }
                    
                    break;
                case 'D':
                    Position = new Vector2(Position.X + 0.2f, Position.Y);
                    switch (num_texture)
                    {
                        case 0:
                            text = "pacmanDroite0";
                            break;
                        case 1:
                            text = "pacmanDroite1";
                            break;
                        case 2:
                            text = "pacman_f";
                            break;
                    }
                    break;
                case 'H':
                    Position = new Vector2(Position.X, Position.Y - 0.2f);
                    switch (num_texture)
                    {
                        case 0:
                            text = "pacmanHaut0";
                            break;
                        case 1:
                            text = "pacmanHaut1";
                            break;
                        case 2:
                            text = "pacman_4f";
                            break;
                    }
                    break;
                case 'B':
                    Position = new Vector2(Position.X, Position.Y + 0.2f);
                    switch (num_texture)
                    {
                        case 0:
                            text = "pacmanBas0";
                            break;
                        case 1:
                            text = "pacmanBas1";
                            break;
                        case 2:
                            text = "pacman_3f";
                            break;
                    }
                    break;
            }
        }

        public Vector2 getPositionSuivante()
        {
            Vector2 nextPosition = new Vector2();
            switch (this.Direction)
            {
                case 'G':
                    nextPosition = new Vector2(Position.X - 0.2f, Position.Y);
               
                    break;
                case 'D':
                    nextPosition = new Vector2(Position.X + 0.2f, Position.Y);
                 
                    break;
                case 'H':
                    nextPosition = new Vector2(Position.X, Position.Y - 0.2f);
                   
                    break;
                case 'B':
                    nextPosition = new Vector2(Position.X, Position.Y + 0.2f);
                   
                    break;
            }
            return nextPosition;
        }

        public Vector2 getcase(Vector2 pos)
        {
            Vector2 cases;

            switch (direction)
            {
                case 'G':
                    cases = new Vector2((int)pos.X + 1, (int)pos.Y);
                    break;
                
                case 'D':
                    cases = new Vector2((int)pos.X, (int)pos.Y);
                    break;

                case 'H':
                    cases = new Vector2((int)pos.X , (int)pos.Y -1);
                    break;

                case 'B':
                    cases = new Vector2((int)pos.X , (int)pos.Y );
                    break;
                default:
                    cases = new Vector2(42,42);
                    break;
            }
            return cases;
        }

    }
}   